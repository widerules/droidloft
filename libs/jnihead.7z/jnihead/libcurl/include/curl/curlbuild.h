#if ANDROID
	#include "curlbuild_android.h"
#elif IOS
	#include "curlbuild_ios.h"
#elif MACOSX
	#include "curlbuild_macosx.h"
#endif
