#if ANDROID
	#include "curl_config_android.h"
#elif IOS
	#include "curl_config_ios.h"
#elif MACOSX
	#include "curl_config_macosx.h"
#endif
