/*
 * Copyright (c) 2010 WiYun Inc.

 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:

 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#ifndef __wyMemory_h__
#define __wyMemory_h__

#include <stdlib.h>

// uncomment it if want to enable memory tracking
//#define MEMORY_TRACKING

#if MEMORY_TRACKING

/*
 * overloaded operators for C++
 */

void* operator new(size_t n, const char* file, int line);
void* operator new[](size_t n, const char* file, int line);
void operator delete(void* p, const char* file, int line);
void operator delete(void* p) throw();

/*
 * overloaded functions for C
 */

#ifdef __cplusplus
extern "C" {
#endif

typedef struct wyMemoryRecord {
	/**
	 * start address of allocated memory
	 */
	void* start;

	/**
	 * memory size
	 */
	int size;

	/**
	 * source file name where allocation occurs
	 */
	const char* file;

	/**
	 * source file line where allocation occurs
	 */
	int line;

	/**
	 * next record
	 */
	struct wyMemoryRecord* next;
} wyMemoryRecord;

/**
 * insert a memroy allocation record into list
 *
 * @param r \link wyMemoryRecord wyMemoryRecord\endlink
 */
void addRecord(wyMemoryRecord* r);

/**
 * find a memory record in list
 *
 * @param p pointer to allocated memory
 * @return record or NULL if not found
 */
wyMemoryRecord* findRecord(void* p);

/**
 * remove a memory record from list
 *
 * @param r record pointer
 * @return removed record pointer, or NULL if not found
 */
wyMemoryRecord* removeRecord(wyMemoryRecord* r);

/**
 * print all memory record info
 */
void wyMemoryDumpRecord();

/**
 * print summary info of all records
 */
void wyMemoryUsageReport();

/**
 * malloc overload
 */
void* _wyMalloc(size_t size, const char* file, int line, const char* logTag);

/**
 * calloc overload
 */
void* _wyCalloc(size_t nitems, size_t size, const char* file, int line);

/**
 * realloc overload
 */
void* _wyRealloc(void* ptr, size_t size, const char* file, int line);

/**
 * free overload
 */
void _wyFree(void* ptr, const char* file, int line);

/*
 * macro for alloc and free
 */

#define wyMalloc(size) _wyMalloc(size, __FILE__, __LINE__, "MALLOC")
#define wyCalloc(nitems, size) _wyCalloc(nitems, size, __FILE__, __LINE__)
#define wyRealloc(ptr, size) _wyRealloc(ptr, size, __FILE__, __LINE__)
#define wyFree(ptr) _wyFree(ptr, __FILE__, __LINE__)
#define WYNEW new(__FILE__, __LINE__)
#define WYDELETE(object) delete object
#define WYNEWARR(t, s) new t[(s)]
#define WYDELETEARR(object) delete[] (object)

#ifdef __cplusplus
}
#endif

#else

#define wyMalloc malloc
#define wyCalloc calloc
#define wyRealloc realloc
#define wyFree free
#define WYNEW new
#define WYDELETE(object) delete object
#define WYNEWARR(t, s) new t[(s)]
#define WYDELETEARR(object) delete[] (object)

#endif // #if MEMORY_TRACKING

#endif // __wyMemory_h__
