/*
 * Copyright (c) 2010 WiYun Inc.

 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:

 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#ifndef __wyGlobal_h__
#define __wyGlobal_h__

#include "wyDevice.h"

/// WiEngine version
#define WIENGINE_VERSION "3.7.0"

// opengl headers
#if ANDROID
	#include <GLES/gl.h>
	#include <GLES/glext.h>
#elif IOS
	#import <OpenGLES/ES1/gl.h>
	#import <OpenGLES/ES1/glext.h>
	#import <OpenGLES/ES2/gl.h>
	#import <OpenGLES/ES2/glext.h>
#elif MACOSX
	#import <OpenGL/gl.h>
	#import <OpenGL/glext.h>

	// mapping between OpenGLES and OpenGL
	#define GL_FRAMEBUFFER_BINDING_OES GL_FRAMEBUFFER_BINDING
	#define GL_FRAMEBUFFER_OES GL_FRAMEBUFFER
	#define GL_COLOR_ATTACHMENT0_OES GL_COLOR_ATTACHMENT0
	#define GL_FRAMEBUFFER_UNSUPPORTED_OES GL_FRAMEBUFFER_UNSUPPORTED
	#define glGenFramebuffersOES glGenFramebuffers
	#define glBindFramebufferOES glBindFramebuffer
	#define glFramebufferTexture2DOES glFramebufferTexture2D
	#define GL_POINT_SPRITE_OES GL_POINT_SPRITE
	#define GL_COORD_REPLACE_OES GL_COORD_REPLACE
	#define GL_POINT_SIZE_ARRAY_OES GL_POINT_SIZE_ARRAY_APPLE
	#define glPointSizePointerOES glPointSizePointerAPPLE
	#define glCheckFramebufferStatusOES glCheckFramebufferStatus
	#define glDeleteFramebuffersOES glDeleteFramebuffers
	#define glTexParameterx glTexParameteri
	#define glOrthof glOrtho
	#define glDepthRangef glDepthRange
	#define glClearDepthf glClearDepth
	#define glFrustumf glFrustum
#endif

// blend func
#define DEFAULT_BLEND_SRC GL_SRC_ALPHA
#define DEFAULT_BLEND_DST GL_ONE_MINUS_SRC_ALPHA

// map endian methods
#if ANDROID
	#include <endian.h>
#elif IOS || MACOSX
	#import <CoreFoundation/CoreFoundation.h>
	#define letoh32 CFSwapInt32LittleToHost
	#define letoh16 CFSwapInt16LittleToHost
	#define htobe32 CFSwapInt32HostToBig
	#define betoh32	CFSwapInt32BigToHost
	#define betoh16 CFSwapInt16BigToHost
#endif

// default font
#if ANDROID
	#define WY_DEFAULT_FONT "DroidSans"
#elif IOS || MACOSX
	#define WY_DEFAULT_FONT "Verdana"
#endif

// built-in strings
#define WY_OK_EN "OK"
#define WY_OK_ZH "确定"
#define WY_CANCEL_EN "Cancel"
#define WY_CANCEL_ZH "取消"

// GL context and GL view definition
#if ANDROID
	#define wyGLSurfaceView jobject
	#define wyGLContext jobject
#elif IOS
	#import "WYEAGLView.h"
	#define wyGLSurfaceView WYEAGLView*
	#define wyGLContext WYEAGLView*
#elif MACOSX
	#import "WYOpenGLView.h"
	#define wyGLSurfaceView WYOpenGLView*
	#define wyGLContext WYOpenGLView*
#endif

// platform event universal type
#if ANDROID
	#define wyPlatformMotionEvent jobject
	#define wyPlatformKeyEvent jobject
#elif IOS
	#import "WYUIEvent.h"
	#import "WYUITouch.h"
	#define wyPlatformMotionEvent WYUIEvent*
	#define wyPlatformKeyEvent wyKeyEvent*
#elif MACOSX
	#define wyPlatformKeyEvent NSEvent*
	#define wyPlatformMotionEvent NSEvent*
#endif

// wide char type
#if ANDROID
	typedef unsigned short wyWChar;
#elif IOS || MACOSX
	#define wyWChar UniChar
	#define char16_t UniChar
#endif

#endif // __wyGlobal_h__
