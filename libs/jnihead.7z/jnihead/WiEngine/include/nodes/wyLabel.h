/*
 * Copyright (c) 2010 WiYun Inc.

 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:

 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#ifndef __wyLabel_h__
#define __wyLabel_h__

#include "wyTextureNode.h"

/**
 * @class wyLabel
 *
 * \if English
 * wrapper of label
 * \else
 * 标签的封装
 * \endif
 */
class wyLabel : public wyTextureNode {
private:
	/**
	 * \if English
	 * font size
	 * \else
	 * 字体大小
	 * \endif
	 */
	float m_fontSize;

	/**
	 * \if English
	 * font style
	 * \else
	 * 字体样式
	 * \endif
	 */
	wyFontStyle m_fontStyle;

	/**
	 * \if English
	 * font name
	 * \else
	 * 字体名字
	 * \endif
	 */
	const char*	m_fontName;

	/**
	 * \if English
	 * path of font to be used
	 * \else
	 * 指定所用字体的路径
	 * \endif
	 */
	const char* m_fontPath;

	/**
	 * \if English
	 * width of the label, if the content exceeds one single line, new lines will be added
	 * \else
	 * 标签宽度，如内容超过此宽度则折行显示
	 * \endif
	 */
	float m_lineWidth;

protected:
	/**
	 * \if English
	 * update the texture
	 * \else
	 * 更新标签的贴图
	 * \endif
	 */
	void update();

public:
	/**
	 * \if English
	 * factory function, used to create a new instance with autoRelease enabled
	 *
	 * @param resId the resource identifier of a string
	 * \else
	 * 获得\link wyLabel wyLabel对象指针\endlink
	 *
	 * @param resId 标签上字符串的资源id
	 * @return \link wyLabel wyLabel对象\endlink
	 * \endif
	 */
	static wyLabel* make(int resId);

	/**
	 * \if English
	 * factory function, used to create a new instance with autoRelease enabled
	 *
	 * @param resId the resource identifier of a string
	 * @param fontSize font size, in pixels
	 * @param width the width of the label, in pixels
	 * @param fontPath path of the font to be used
	 * \else
	 * 获得\link wyLabel wyLabel对象指针\endlink
	 *
	 * @param resId 标签上字符串的资源id
	 * @param fontSize 文字大小. 单位是像素.
	 * @param width 文字的最大行宽，如果文字很长，则可能会折行成为多行标签. 单位是像素.
	 * @param fontPath 字体
	 * @return \link wyLabel wyLabel对象指针\endlink
	 * \endif
	 */
	static wyLabel* make(int resId, float fontSize, float width = 0, const char* fontPath = NULL);

	/**
	 * \if English
	 * factory function, used to create a new instance with autoRelease enabled
	 *
	 * @param resId the resource identifier of a string
	 * @param fontSize font size, in pixels
	 * @param style font style
	 * @param width the width of the label, in pixels
	 * @param fontName font name
	 * \else
	 * 获得\link wyLabel wyLabel对象指针\endlink
	 *
	 * @param resId 标签上字符串的资源id
	 * @param fontSize 文字大小. 单位是像素.
	 * @param style 字体样式
	 * @param width 文字的最大行宽，如果文字很长，则可能会折行成为多行标签. 单位是像素.
	 * @param fontName 字体名称
	 * @return \link wyLabel wyLabel对象指针\endlink
	 * \endif
	 */
	static wyLabel* make(int resId, float fontSize, wyFontStyle style, float width = 0, const char* fontName = NULL);

	/**
	 * \if English
	 * factory function, used to create a new instance with autoRelease enabled
	 *
	 * @param text null-terminated C string
	 * \else
	 * 获得\link wyLabel wyLabel对象指针\endlink
	 *
	 * @param text 显示内容的文字字符串
	 * @return \link wyLabel wyLabel对象指针\endlink
	 * \endif
	 */
	static wyLabel* make(const char* text);

	/**
	 * \if English
	 * factory function, used to create a new instance with autoRelease enabled
	 *
	 * @param text null-terminated C string
	 * @param fontSize font size, in pixels
	 * @param width width of the Label, in pixels
	 * @param fontPath path of the font
	 * \else
	 * 获得\link wyLabel wyLabel对象指针\endlink
	 *
	 * @param text 显示内容的文字字符串
	 * @param fontSize 文字大小. 单位是像素.
	 * @param width 文字的最大行宽，如果文字很长，则可能会折行成为多行标签. 单位是像素.
	 * @param fontPath 字体
	 * @return \link wyLabel wyLabel对象指针\endlink
	 * \endif
	 */
	static wyLabel* make(const char* text, float fontSize, float width = 0, const char* fontPath = NULL);

	/**
	 * \if English
	 * factory function, used to create a new instance with autoRelease enabled
	 *
	 * @param text null-terminated C string
	 * @param fontSize font size, in pixels
	 * @param style font style
	 * @param width width of the label, in pixels
	 * @param fontName font name
	 * \else
	 * 获得\link wyLabel wyLabel对象指针\endlink
	 *
	 * @param text 显示内容的文字字符串
	 * @param fontSize 文字大小. 单位是像素.
	 * @param style 字体样式
	 * @param width 文字的最大行宽，如果文字很长，则可能会折行成为多行标签. 单位是像素.
	 * @param fontName 字体名称
	 * @return \link wyLabel wyLabel对象指针\endlink
	 * \endif
	 */
	static wyLabel* make(const char* text, float fontSize, wyFontStyle style, float width = 0, const char* fontName = NULL);

	/**
	 * \if English
	 * constructor
	 * \else
	 * 构造函数
	 * \endif
	 */
	wyLabel();

	/**
	 * \if English
	 * constructor
	 *
	 * @param text null-terminated C string
	 * @param fontSize font size, in pixels
	 * @param width width of the label
	 * @param fontPath path of the font
	 * \else
	 * 构造函数
	 *
	 * @param text 显示内容的文字字符串
	 * @param fontSize 文字大小
	 * @param width 文字的最大行宽，如果文字很长，则可能会折行成为多行标签
	 * @param fontPath 自定义字体在assets下的路径，如果为NULL表示使用系统缺省字体
	 * \endif
	 */
	wyLabel(const char* text, float fontSize, float width = 0, const char* fontPath = NULL);

	/**
	 * \if English
	 * constructor
	 *
	 * @param text null-terminated C string
	 * @param fontSize font size, in pixels
	 * @param style font style
	 * @param width width of the label, in pixels
	 * @param fontName font name
	 * \else
	 * 构造函数
	 *
	 * @param text 显示内容的文字字符串
	 * @param fontSize 文字大小
	 * @param style 字体样式
	 * @param width 文字的最大行宽，如果文字很长，则可能会折行成为多行标签
	 * @param fontName 字体名称, 如果为NULL表示使用系统缺省字体
	 * \endif
	 */
	wyLabel(const char* text, float fontSize, wyFontStyle style, float width = 0, const char* fontName = NULL);

	/**
	 * \if English
	 * destructor
	 * \else
	 * 析构函数
	 * \endif
	 */
	virtual ~wyLabel();

	/**
	 * \if English
	 * getter
	 *
	 * @return null-terminated C string
	 * \else
	 * 获得文字字符串
	 *
	 * @return 文字字符串
	 * \endif
	 */
	virtual const char* getText() { return m_tex->getText(); }

	/**
	 * \if English
	 * setter
	 *
	 * @param text C string
	 * \else
	 * 设置文字字符串
	 *
	 * @param text 文字字符串
	 * \endif
	 */
	virtual void setText(const char* text) { setString(text); }

	/**
	 * \if English
	 * setter
	 *
	 * @param text C string
	 * \else
	 * 设置文字字符串
	 *
	 * @param text 文字字符串
	 * \endif
	 */
	void setString(const char* text);

	/**
	 * \if English
	 * setter
	 *
	 * @param resId the resource identifier of the string
	 * \else
	 * 通过一个字符串资源id设置标签文字
	 *
	 * @param resId 字符串资源id
	 * \endif
	 */
	void setString(int resId);

	/**
	 * \if English
	 * set the font size
	 *
	 * @param fontSize font size
	 * \else
	 * 设置字体大小
	 *
	 * @param fontSize 字体大小
	 * \endif
	 */
	void setFontSize(float fontSize);

	/**
	 * \if English
	 * getter
	 * \else
	 * 获得字体大小
	 * \endif
	 */
	float getFontSize() { return m_fontSize; }

	/**
	 * \if English
	 * setter
	 *
	 * @param fontStyle font style, \link wyFontStyle wyFontStyle\endlink
	 * \else
	 * 设置字体样式
	 *
	 * @param fontStyle 字体样式
	 * \endif
	 */
	void setFontStyle(wyFontStyle fontStyle);

	/**
	 * \if English
	 * getter
	 * \else
	 * 获得字体样式
	 * \endif
	 */
	wyFontStyle getFontStyle() { return m_fontStyle; }

	/**
	 * \if English
	 * setter
	 *
	 * @param fontName font name
	 * \else
	 * 设置所用字体名字
	 *
	 * @param fontName 字体名字
	 * \endif
	 */
	void setFontName(const char* fontName);

	/**
	 * \if English
	 * getter
	 * \else
	 * 获得正在使用的字体名字
	 * \endif
	 */
	const char* getFontName() { return m_fontName; }

	/**
	 * \if English
	 * setter
	 *
	 * @param fontPath font path
	 * \else
	 * 设置字体路径
	 *
	 * fontPath 字体路径
	 * \endif
	 */
	void setFontPath(const char* fontPath);

	/**
	 * \if English
	 * getter
	 * \else
	 * 获得字体路径
	 * \endif
	 */
	const char* getFontPath() { return m_fontPath; }	

	/**
	 * \if English
	 * setter
	 *
	 * @param lineWidth label width
	 * \else
	 * 设置标签宽度
	 * \endif
	 */
	void setLineWidth(float lineWidth);

	/**
	 * \if English
	 * getter
	 * \else
	 * 获得标签宽度
	 * \endif
	 */
	float getLineWidth() { return m_lineWidth; }
};

#endif // __wyLabel_h__
