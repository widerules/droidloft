/*
 * Copyright (c) 2010 WiYun Inc.

 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:

 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#ifndef __wyTargetSelector_h__
#define __wyTargetSelector_h__

#include "wyObject.h"
#include <stdbool.h>
#if ANDROID
	#include <jni.h>
#endif

class wyTargetSelector;

/*
 * equals function of target selector
 */

#ifdef __cplusplus
extern "C" {
#endif

bool wyTargetSelectorEquals(wyTargetSelector* ts1, wyTargetSelector* ts2);

#ifdef __cplusplus
}
#endif

/**
 * @typedef wySEL
 *
 * \if English
 * pointer to a method in wyObject subclass
 * \else
 * 指向wyObject子类中某个方法的指针
 * \endif
 */
typedef void (wyObject::*wySEL)(void*);

/**
 * \if English
 * macro to get a wySEL
 * \else
 * 用于得到wySEL的宏
 * \endif
 */
#define SEL(f) (wySEL)(&f)

/**
 * @class wyTargetSelector
 *
 * \if English
 * it indicates a callback
 * \else
 * 定时器回调的封装
 * \endif
 */
class wyTargetSelector : public wyObject {
private:
	/**
	 * \if English
	 * callback target, must be a wyObject subclass
	 * \else
	 * native层回调的\link wyObject wyObject对象指针\endlink
	 * \endif
	 */
	wyObject* m_callback;

	/**
	 * \if English
	 * id of this target selector
	 * \else
	 * 标识id
	 * \endif
	 */
	int m_id;

	/**
	 * \if English
	 * the time between last calling and now
	 * \else
	 * 标识距离上次触发所持续的时间，例如如果按三帧刷新一次，则累计三帧消耗的时间
	 * \endif
	 */
	float m_delta;

	/**
	 * \if English
	 * argument of callback
	 * \else
	 * native层回调的参数
	 * \endif
	 */
	void* m_data;

	/**
	 * \if English
	 * callback function of a class
	 * \else
	 * 自定义函数回调
	 * \endif
	 */
	wySEL m_sel;

#if ANDROID
	/**
	 * \if English
	 * callback object in java side
	 * \else
	 * java层回调对象
	 * \endif
	 */
	jobject j_callback;
#endif

public:
	/**
	 * \if English
	 * static constructor
	 *
	 * @param callback callback target, must be a wyObject subclass
	 * @param id id of this target selector
	 * @param data argument of callback, or NULL if none
	 * @return \link wyTargetSelector wyTargetSelector\endlink
	 * \else
	 * 静态构造函数
	 *
	 * @param callback native层回调的\link wyObject wyObject对象指针\endlink
	 * @param id 标识id
	 * @param data 额外数据指针
	 * @return \link wyTargetSelector wyTargetSelector\endlink
	 * \endif
	 */
	static wyTargetSelector* make(wyObject* callback, int id, void* data);

	/**
	 * \if English
	 * static constructor
	 *
	 * @param target object of callback function
	 * @param sel pointer to callback function
	 * @param data extra data pointer
	 * @return \link wyTargetSelector wyTargetSelector\endlink
	 * \else
	 * 静态构造函数
	 *
	 * @param target 回调函数所在的类实例
	 * @param sel 指向回调函数的指针
	 * @param data 额外数据指针
	 * @return \link wyTargetSelector wyTargetSelector\endlink
	 * \endif
	 */
	static wyTargetSelector* make(wyObject* target, wySEL sel, void* data);

#if ANDROID
	/**
	 * \if English
	 * static constructor
	 *
	 * @param callback java layer callback
	 * \else
	 * 静态构造函数
	 *
	 * @param callback java层回调对象
	 * \endif
	 */
	static wyTargetSelector* make(jobject callback);
#endif

	/**
	 * \if English
	 * constructor
	 *
	 * @param callback native层回调的\link wyObject wyObject对象指针\endlink
	 * @param id 标识id
	 * @param data 额外数据指针
	 * \else
	 * 构造函数
	 *
	 * @param callback native层回调的\link wyObject wyObject对象指针\endlink
	 * @param id 标识id
	 * @param data 额外数据指针
	 * \endif
	 */
	wyTargetSelector(wyObject* callback, int id, void* data);

	/**
	 * \if English
	 * constructor
	 *
	 * @param target object of callback function
	 * @param sel pointer to callback function
	 * @param data extra data pointer
	 * \else
	 * 构造函数
	 *
	 * @param target 回调函数所在的类实例
	 * @param sel 指向回调函数的指针
	 * @param data 额外数据指针
	 * \endif
	 */
	wyTargetSelector(wyObject* target, wySEL sel, void* data);

#if ANDROID
	/**
	 * \if English
	 * constructor
	 *
	 * @param callback java layer callback
	 * \else
	 * 构造函数
	 *
	 * @param callback java层回调对象
	 * \endif
	 */
	wyTargetSelector(jobject callback);
#endif

	virtual ~wyTargetSelector();
	
	/**
	 * \if English
	 * overload of ==
	 * \else
	 * ==操作符的重载
	 * \endif
	 */
	bool operator==(wyTargetSelector& ts);

	/**
	 * \if English
	 * set time between last calling and now
	 *
	 * @param delta time between last calling and now
	 * \else
	 * 设置距离上次触发所持续的时间，例如如果按三帧刷新一次，则累计三帧消耗的时间
	 *
	 * @param delta 时间
	 * \endif
	 */
	void setDelta(float delta);

	/**
	 * \if English
	 * invoke callback function
	 * \else
	 * 触发回调
	 * \endif
	 */
	void invoke();

	/**
	 * \if English
	 * get callback target, must be a wyObject subclass
	 *
	 * @return callback target, must be a wyObject subclass
	 * \else
	 * 获得native层回调的\link wyObject wyObject对象指针\endlink
	 *
	 * @return native层回调的\link wyObject wyObject对象指针\endlink
	 * \endif
	 */
	wyObject* getCallback() { return m_callback; }

#if ANDROID
	/**
	 * \if English
	 * get callback object in java side
	 *
	 * @return callback object in java side
	 * \else
	 * 获得java层回调对象
	 *
	 * @return java层回调对象
	 * \endif
	 */
	jobject getJavaCallback() { return j_callback; }
#endif

	/**
	 * \if English
	 * get id of target selector
	 *
	 * @return id of target selector
	 * \else
	 * 获得标识id
	 *
	 * @return 标识id
	 * \endif
	 */
	int getId() { return m_id; }

	/**
	 * \if English
	 * set id of target selector
	 *
	 * @param id id of target selector
	 * \else
	 * 设置标识id
	 *
	 * @param id 标识id
	 * \endif
	 */
	void setId(int id) { m_id = id; }

	/**
	 * \if English
	 * get time between last calling and now
	 *
	 * @return time between last calling and now
	 * \else
	 * 获得距离上次触发所持续的时间，例如如果按三帧刷新一次，则累计三帧消耗的时间
	 *
	 * @return 时间
	 * \endif
	 */
	float getDelta() { return m_delta; }

	/**
	 * \if English
	 * get argument of callback function
	 *
	 * @return argument of callback function
	 * \else
	 * 获得native层回调的参数
	 *
	 * @return native层回调的参数
	 * \endif
	 */
	void* getData() { return m_data; }
};

#endif // __wyTargetSelector_h__
