#ifndef __wyPerformance_h__
#define __wyPerformance_h__

#ifdef __cplusplus
extern "C" {
#endif

/**
 * \if English
 * start to record time
 *
 * @param name name for this recording
 * \else
 * 开始记录时间
 *
 * @param name 输出时间时显示的字符串，用来标识是什么时间
 * \endif
 */
void wyRecordTime(const char* name);

/**
 * \if English
 * output time to log
 * \else
 * 输出时间
 * \endif
 */
void wyOutputTime();

#ifdef __cplusplus
}
#endif

#endif // __wyPerformance_h__
